% test_nt_dataview


x=randn(1000,10);
nt_dataview(x);
